import UIKit
import RxSwift
import RxCocoa

class RootController: UINavigationController {
    override func showMenu() {
        performSegue(withIdentifier: "ShowMenu", sender: nil)
    }
}

class MenuViewController: UIViewController {
    @IBOutlet private var tableView: UITableView!
    
    private let viewModel = MenuViewModel()
    private let bag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bindOutput()
    }
    
    private func bindOutput() {
        bindTableViewOutput()
        bindIdentifiers()
    }
    private func bindTableViewOutput() {
        tableView.rx
            .drive(items: viewModel.menuItems)
            .disposed(by: bag)
    }
    private func bindIdentifiers() {
        viewModel.identifiers
            .drive(onNext: { [unowned self] identifier in
                //DispatchQueue.main.async {
                    let alert = UIAlertController(
                        title: "Menu Item Tapped!",
                        message: identifier,
                        preferredStyle: .alert
                    )
                    
                    alert.addAction(.init(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                //}
            })
            .disposed(by: bag)
    }
}

class MenuViewModel {
    let identifiers: Driver<String>
    let menuItems: Driver<[TableViewSection]>
    
    init() {
        let identifiers = Driver<String>.create()
        self.identifiers = identifiers.output
        
        self.menuItems = .just(MenuViewModel.buildTableSections(selection: identifiers.input))
    }
    
    static func buildTableSections(selection: AnyObserver<String>) -> [TableViewSection] {
        return [MenuItemsSection(items: [
            MenuItemViewModel(identifier: "settings", title: "settings", selection: selection),
            MenuItemViewModel(identifier: "protection", title: "protection", selection: selection),
            MenuItemViewModel(identifier: "paymentHistory", title: "paymentHistory", selection: selection),
            MenuItemViewModel(identifier: "help", title: "help", selection: selection),
            MenuItemViewModel(identifier: "monthlySummary", title: "monthlySummary", selection: selection),
            MenuItemViewModel(identifier: "monthlyStatements", title: "monthlyStatements", selection: selection)
            ])
        ]
    }
}

class MenuItemsSection: TableViewSection {
    let items: [AnyTableViewCellViewModel]
    
    init(items: [MenuItemViewModel]) {
        self.items = items
    }
}

class MenuItemViewModel: TableViewCellViewModel {
    typealias TableCell = MenuItemCell
    
    private let selection: AnyObserver<String>
    let identifier: String
    let title: String
    
    init(identifier: String, title: String, selection: AnyObserver<String>) {
        self.identifier = identifier
        self.title = title
        self.selection = selection
    }
    
    func selected() {
        selection.onNext(identifier)
    }
}

class MenuItemCell: UITableViewCell, ViewModelConfigurable, StoryboardReusable {
    @IBOutlet private var titleLabel: UILabel!
    
    func configure(with viewModel: MenuItemViewModel) {
        titleLabel.text = viewModel.title
        selectionStyle = .none
    }
}
