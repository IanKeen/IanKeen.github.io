import UIKit

/// A reusable component
public protocol Reusable: class {
    /// The unique identifier used by this component
    static var reuseIdentifier: String { get }
}

public extension Reusable {
    public static var reuseIdentifier: String {
        return String(describing: self)
    }
}

extension UITableViewCell: Reusable { }

/// A reusable component with a nib
public protocol NibReusable: Reusable {
    static var bundle: Bundle { get }
    static var nib: UINib? { get }
}
public extension NibReusable {
    static var bundle: Bundle { return .main }
}

public extension NibReusable {
    public static var nib: UINib? {
        return UINib(nibName: String(describing: self), bundle: bundle)
    }
}

/// A reusable component from a storyboard
public protocol StoryboardReusable {}
