import UIKit

public protocol AnyTableViewCellViewModel {
    static var reuseIdentifier: String { get }
    static func register(with tableView: UITableView)
    
    func dequeue(from tableView: UITableView, at indexPath: IndexPath) -> UITableViewCell
    func selected()
}

extension AnyTableViewCellViewModel {
    public func selected() { }
}
