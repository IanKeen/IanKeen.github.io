import UIKit

public protocol TableViewSection {
    var headerTitle: String? { get }
    var footerTitle: String? { get }
    var items: [AnyTableViewCellViewModel] { get }
}

public extension TableViewSection {
    var headerTitle: String? { return nil }
    var footerTitle: String? { return nil }
}
