import UIKit

// swiftlint:disable line_length

// TODO : for some reason the last constraint on these extensions stopped working in swift 4.1
// still trying to figure out why.. will update as soon as I know
// I've filed a bug: https://bugs.swift.org/projects/SR/issues/SR-7462

public extension TableViewCellViewModel where TableCell: ViewModelConfigurable { //}, TableCell.Configuration == Self {
    public func dequeue(from tableView: UITableView, at indexPath: IndexPath) -> UITableViewCell {
        guard
            let cell = tableView.dequeueReusableCell(withIdentifier: TableCell.reuseIdentifier, for: indexPath) as? TableCell,
            let viewModel = self as? TableCell.ViewModel
            else { fatalError("Unable to dequeue expected type '\(TableCell.self)'") }
        
        cell.configure(with: viewModel)
        
        return cell
    }
}
