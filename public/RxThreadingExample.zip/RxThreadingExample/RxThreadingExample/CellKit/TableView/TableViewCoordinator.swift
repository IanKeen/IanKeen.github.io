import UIKit

public extension UITableView {
    public var coordinator: TableViewCoordinator? {
        get { return self[dynamic: #function] }
        set { self[dynamic: #function] = newValue }
    }
}

public extension UITableView {
    public enum SelectionBehavior {
        case none
        case autoDeselect
    }
    public func update(data: [TableViewSection], selectionBehavior: SelectionBehavior = .autoDeselect) {
        coordinator = coordinator ?? TableViewCoordinator(tableView: self, selectionBehavior: selectionBehavior)
        coordinator?.update(data: data)
    }
}

public class TableViewCoordinator: NSObject, UITableViewDataSource, UITableViewDelegate {
    // MARK: - Private Properties
    private var data: [TableViewSection] = [] {
        didSet { tableView?.reloadData() }
    }
    private var registered: Set<String> = []
    private weak var tableView: UITableView?
    private let selectionBehavior: UITableView.SelectionBehavior
    
    // MARK: - Lifecycle
    public init(tableView: UITableView, selectionBehavior: UITableView.SelectionBehavior = .autoDeselect) {
        self.tableView = tableView
        self.selectionBehavior = selectionBehavior
        
        super.init()
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    // MARK: - Public Functions
    public func update(data: [TableViewSection]) {
        self.data = data
    }
    
    // MARK: - UITableViewDataSource
    public func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].items.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = data[indexPath.section].items[indexPath.row]
        let itemType = type(of: item)
        
        if !registered.contains(itemType.reuseIdentifier) {
            itemType.register(with: tableView)
            registered.insert(itemType.reuseIdentifier)
        }
        
        return item.dequeue(from: tableView, at: indexPath)
    }
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].headerTitle
    }
    
    public func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return data[section].footerTitle
    }
    
    // MARK: - UITableViewDelegate
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        data[indexPath.section].items[indexPath.row].selected()
        if selectionBehavior == .autoDeselect { tableView.deselectRow(at: indexPath, animated: true) }
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}
