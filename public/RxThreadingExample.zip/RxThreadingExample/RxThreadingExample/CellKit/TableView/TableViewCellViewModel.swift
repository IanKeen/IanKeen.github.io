import UIKit

public protocol TableViewCellViewModel: AnyTableViewCellViewModel {
    associatedtype TableCell: UITableViewCell
}

public extension TableViewCellViewModel {
    public static var reuseIdentifier: String {
        return TableCell.reuseIdentifier
    }
    public static func register(with tableView: UITableView) {
        switch TableCell.self {
        case is StoryboardReusable.Type:
            break
        case let cell as NibReusable.Type:
            tableView.register(cell.nib, forCellReuseIdentifier: cell.reuseIdentifier)
        default:
            tableView.register(TableCell.self, forCellReuseIdentifier: TableCell.reuseIdentifier)
        }
    }
    public func dequeue(from tableView: UITableView, at indexPath: IndexPath) -> UITableViewCell {
        return tableView.dequeueReusableCell(withIdentifier: TableCell.reuseIdentifier, for: indexPath)
    }
}
