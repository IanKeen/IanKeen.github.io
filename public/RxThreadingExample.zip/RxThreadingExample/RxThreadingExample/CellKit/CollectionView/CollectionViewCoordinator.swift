import UIKit

public extension UICollectionView {
    public var coordinator: CollectionViewCoordinator? {
        get { return self[dynamic: #function] }
        set { self[dynamic: #function] = newValue }
    }
}

public extension UICollectionView {
    public func update(data: [CollectionViewSection]) {
        coordinator = coordinator ?? CollectionViewCoordinator(collectionView: self)
        coordinator?.update(data: data)
    }
}

public class CollectionViewCoordinator: NSObject, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    // MARK: - Private Properties
    private var data: [CollectionViewSection] = [] {
        didSet { collectionView?.reloadData() }
    }
    private var registered: Set<String> = []
    private weak var collectionView: UICollectionView?
    
    // MARK: - Lifecycle
    public init(collectionView: UICollectionView) {
        self.collectionView = collectionView
        
        super.init()
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    // MARK: - Public Functions
    public func update(data: [CollectionViewSection]) {
        self.data = data
    }
    
    // MARK: - UICollectionViewDataSource
    public func numberOfSections(in collectionView: UICollectionView) -> Int {
        return data.count
    }
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data[section].items.count
    }
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = data[indexPath.section].items[indexPath.item]
        let itemType = type(of: item)
        
        if !registered.contains(itemType.reuseIdentifier) {
            itemType.register(with: collectionView)
            registered.insert(itemType.reuseIdentifier)
        }
        
        return item.dequeue(from: collectionView, at: indexPath)
    }
    
    // MARK: - UICollectionViewDelegate
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        data[indexPath.section].items[indexPath.item].selected()
    }
    public func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        data[indexPath.section].flowLayout.collectionView?(collectionView, willDisplay: cell, forItemAt: indexPath)
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let value = data[indexPath.section].flowLayout
            .collectionView?(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
        
        return value ?? CGSize(width: 10, height: 10)
    }
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        let value = data[section].flowLayout
            .collectionView?(collectionView, layout: collectionViewLayout, insetForSectionAt: section)
        
        return value ?? .zero
    }
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        let value = data[section].flowLayout
            .collectionView?(collectionView, layout: collectionViewLayout, minimumLineSpacingForSectionAt: section)
        
        return value ?? 0
    }
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        let value = data[section].flowLayout
            .collectionView?(collectionView, layout: collectionViewLayout, minimumInteritemSpacingForSectionAt: section)
        
        return value ?? 0
    }
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        let value = data[section].flowLayout
            .collectionView?(collectionView, layout: collectionViewLayout, referenceSizeForHeaderInSection: section)
        
        return value ?? .zero
    }
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        let value = data[section].flowLayout
            .collectionView?(collectionView, layout: collectionViewLayout, referenceSizeForFooterInSection: section)
        
        return value ?? .zero
    }
    
    // MARK: - UIScrollViewDelegate
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard let collectionView = scrollView as? UICollectionView else { return }
        
        for section in data {
            section.flowLayout.collectionViewDidScroll?(collectionView)
        }
    }
}
