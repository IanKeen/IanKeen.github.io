import UIKit

public protocol AnyCollectionViewCellViewModel {
    static var reuseIdentifier: String { get }
    static func register(with collectionView: UICollectionView)
    
    func dequeue(from collectionView: UICollectionView, at indexPath: IndexPath) -> UICollectionViewCell
    func selected()
}

extension AnyCollectionViewCellViewModel {
    public func selected() { }
}
