import UIKit

public protocol CollectionViewSection {
    var flowLayout: CollectionViewLayoutDelegate { get }
    var items: [AnyCollectionViewCellViewModel] { get }
}

public extension CollectionViewSection where Self: CollectionViewLayoutDelegate {
    public var flowLayout: CollectionViewLayoutDelegate { return self }
}
