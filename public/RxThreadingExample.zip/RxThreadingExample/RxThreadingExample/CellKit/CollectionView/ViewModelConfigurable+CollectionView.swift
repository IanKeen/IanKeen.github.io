import UIKit

// swiftlint:disable line_length

// TODO : for some reason the last constraint on these extensions stopped working in swift 4.1
// still trying to figure out why.. will update as soon as I know
// I've filed a bug: https://bugs.swift.org/projects/SR/issues/SR-7462

public extension CollectionViewCellViewModel where CollectionCell: ViewModelConfigurable { //}, CollectionCell.Configuration == Self {
    public func dequeue(from collectionView: UICollectionView, at indexPath: IndexPath) -> UICollectionViewCell {
        guard
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionCell.reuseIdentifier, for: indexPath) as? CollectionCell,
            let viewModel = self as? CollectionCell.ViewModel
            else { fatalError("Unable to dequeue expected type '\(CollectionCell.self)'") }
        
        cell.configure(with: viewModel)
        
        return cell
    }
}
