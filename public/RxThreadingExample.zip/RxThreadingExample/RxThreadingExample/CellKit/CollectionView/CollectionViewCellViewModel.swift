import UIKit

public protocol CollectionViewCellViewModel: AnyCollectionViewCellViewModel {
    associatedtype CollectionCell: UICollectionViewCell
}

public extension CollectionViewCellViewModel {
    public static var reuseIdentifier: String {
        return CollectionCell.reuseIdentifier
    }
    public static func register(with collectionView: UICollectionView) {
        switch CollectionCell.self {
        case is StoryboardReusable.Type:
            break
        case let cell as NibReusable.Type:
            collectionView.register(cell.nib, forCellWithReuseIdentifier: cell.reuseIdentifier)
        default:
            collectionView.register(CollectionCell.self, forCellWithReuseIdentifier: CollectionCell.reuseIdentifier)
        }
    }
    public func dequeue(from collectionView: UICollectionView, at indexPath: IndexPath) -> UICollectionViewCell {
        return collectionView.dequeueReusableCell(withReuseIdentifier: CollectionCell.reuseIdentifier, for: indexPath)
    }
}
