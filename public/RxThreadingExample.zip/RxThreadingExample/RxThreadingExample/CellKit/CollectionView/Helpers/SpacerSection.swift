import UIKit

private class SpacingCell: UICollectionViewCell, ViewModelConfigurable {
    func configure(with viewModel: SpacingViewModel) {
        self.contentView.backgroundColor = viewModel.color
    }
}
private class SpacingViewModel: CollectionViewCellViewModel {
    typealias CollectionCell = SpacingCell
    
    let color: UIColor
    let height: CGFloat
    
    init(color: UIColor, height: CGFloat) {
        self.color = color
        self.height = height
    }
}

public class SpacingSection: NSObject, CollectionViewSection, CollectionViewLayoutDelegate {
    // MARK: - Public Properties
    public var items: [AnyCollectionViewCellViewModel] { return [viewModel] }
    
    // MARK: - Private Properties
    private let viewModel: SpacingViewModel
    
    // MARK: - Lifecycle
    public init(color: UIColor = .clear, height: CGFloat = 50) {
        self.viewModel = SpacingViewModel(color: color, height: height)
    }
    
    // MARK: - CollectionViewLayoutDelegate
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width, height: viewModel.height)
    }
}
