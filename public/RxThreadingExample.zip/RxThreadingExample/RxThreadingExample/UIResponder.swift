import UIKit

extension UIResponder {
    @objc @IBAction func showMenu() {
        next?.showMenu()
    }
}
