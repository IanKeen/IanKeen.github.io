import RxSwift
import RxCocoa
import UIKit

extension Reactive where Base: UITableView {
    func drive(items: Driver<[TableViewSection]>) -> Disposable {
        base.coordinator = TableViewCoordinator(tableView: base)
        
        return items.drive(onNext: { items in
            self.base.coordinator?.update(data: items)
        })
    }
}


public extension Driver {
    public static func create(withDefault default: Element? = nil, startingWith value: E) -> (input: AnyObserver<Element>, output: Driver<Element>) {
        let (input, output) = create(withDefault: `default`)
        return (input, output.startWith(value))
    }

    public static func create(withDefault default: Element? = nil) -> (input: AnyObserver<Element>, output: Driver<Element>) {
        let instance = ReplaySubject<Element>.create(bufferSize: 1)
        return (
            AnyObserver(instance),
            instance.asDriver(onErrorDriveWith: `default`.map(Driver.just) ?? .never())
        )
    }
}
