//
//  LoginViewController_Nib.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-28.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit

class LoginViewController_Nib: UIViewController {
    @IBOutlet private var customView: LoginView_Nib!

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        startTrackingKeyboard()
    }
    
    // MARK: - Actions
    @IBAction private func facebookLoginTouchUpInside(sender: UIButton) {
        doWork("Facebook login")
    }
    @IBAction private func googleLoginTouchUpInside(sender: UIButton) {
        doWork("Google login")
    }
    @IBAction private func createAccountTouchUpInside(sender: UIButton) {
        if let email = customView.email.text, !email.isEmpty {
            doWork("Create account for: \(email)")

        } else {
            presentError("Please enter your email")
        }
    }

    // represents some async task, api call etc..
    private func doWork(_ name: String) {
        print(name)
        customView.setWorking(true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.customView.setWorking(false)
        }
    }
}
