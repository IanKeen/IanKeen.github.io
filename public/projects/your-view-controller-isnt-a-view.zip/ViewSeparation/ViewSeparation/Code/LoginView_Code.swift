//
//  LoginView_Code.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-26.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit

class LoginView_Code: UIView {
    // MARK: - Elements
    private lazy var title: UILabel = {
        let label = UILabel()
        label.text = "CleanApp"
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 60)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    lazy private(set) var facebookLogin: UIButton = {
        let button = UIButton()
        button.setTitle("Facebook", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 59/255.0, green: 89/255.0, blue: 152/255.0, alpha: 1.0)
        button.titleLabel?.font = UIFont.systemFont(ofSize: UIFont.buttonFontSize)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    lazy private(set) var googleLogin: UIButton = {
        let button = UIButton()
        button.setTitle("Google", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 214/255.0, green: 45/255.0, blue: 32/255.0, alpha: 1.0)
        button.titleLabel?.font = UIFont.systemFont(ofSize: UIFont.buttonFontSize)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    lazy private var showEmailLogin: UIButton = {
        let button = UIButton()
        button.setTitle("Email", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .gray
        button.titleLabel?.font = UIFont.systemFont(ofSize: UIFont.buttonFontSize)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    lazy private(set) var email: UITextField = {
        let textField = UITextField()
        textField.keyboardType = .emailAddress
        textField.placeholder = "Enter your email address"
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.layer.borderWidth = 0.7
        textField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    lazy private(set) var emailLogin: UIButton = {
        let button = UIButton()
        button.setTitle("Login", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .black
        button.titleLabel?.font = UIFont.systemFont(ofSize: UIFont.buttonFontSize)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    lazy private(set) var cancelEmailLogin: UIButton = {
        let button = UIButton()
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .gray
        button.titleLabel?.font = UIFont.systemFont(ofSize: UIFont.buttonFontSize)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    lazy private var workingBackground: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    lazy private var spinner: UIActivityIndicatorView = {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.hidesWhenStopped = false
        spinner.startAnimating()
        return spinner
    }()

    // MARK: - Private Properties
    private var mode: LoginViewMode = .social {
        didSet { updateUI() }
    }

    // MARK: - Lifecycle
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        configure()
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }

    // MARK: - Private Functions
    private func configure() {
        [title, facebookLogin, googleLogin, showEmailLogin, email, emailLogin, cancelEmailLogin, workingBackground, spinner]
            .forEach(addSubview)

        backgroundColor = .white

        title.topAnchor.constraint(equalTo: topAnchor, constant: 50).isActive = true
        title.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20).isActive = true
        title.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20).isActive = true
        title.heightAnchor.constraint(equalToConstant: 80).isActive = true

        facebookLogin.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20).isActive = true
        facebookLogin.trailingAnchor.constraint(equalTo: centerXAnchor, constant: -5).isActive = true
        facebookLogin.heightAnchor.constraint(equalToConstant: 60).isActive = true
        facebookLogin.bottomAnchor.constraint(equalTo: showEmailLogin.topAnchor, constant: -10).isActive = true

        googleLogin.leadingAnchor.constraint(equalTo: centerXAnchor, constant: 5).isActive = true
        googleLogin.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20).isActive = true
        googleLogin.heightAnchor.constraint(equalToConstant: 60).isActive = true
        googleLogin.bottomAnchor.constraint(equalTo: showEmailLogin.topAnchor, constant: -10).isActive = true

        showEmailLogin.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20).isActive = true
        showEmailLogin.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20).isActive = true
        showEmailLogin.heightAnchor.constraint(equalToConstant: 60).isActive = true
        showEmailLogin.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -20).isActive = true
        showEmailLogin.addTarget(self, action: #selector(toggleState), for: .touchUpInside)

        email.topAnchor.constraint(equalTo: facebookLogin.topAnchor).isActive = true
        email.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20).isActive = true
        email.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20).isActive = true
        email.heightAnchor.constraint(equalToConstant: 60).isActive = true

        emailLogin.topAnchor.constraint(equalTo: email.bottomAnchor, constant: 10).isActive = true
        emailLogin.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20).isActive = true
        emailLogin.trailingAnchor.constraint(equalTo: centerXAnchor, constant: -5).isActive = true
        emailLogin.heightAnchor.constraint(equalToConstant: 60).isActive = true

        cancelEmailLogin.topAnchor.constraint(equalTo: email.bottomAnchor, constant: 10).isActive = true
        cancelEmailLogin.leadingAnchor.constraint(equalTo: centerXAnchor, constant: 5).isActive = true
        cancelEmailLogin.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20).isActive = true
        cancelEmailLogin.heightAnchor.constraint(equalToConstant: 60).isActive = true
        cancelEmailLogin.addTarget(self, action: #selector(toggleState), for: .touchUpInside)

        workingBackground.topAnchor.constraint(equalTo: topAnchor).isActive = true
        workingBackground.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        workingBackground.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        workingBackground.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true

        spinner.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        spinner.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        spinner.widthAnchor.constraint(equalToConstant: 80).isActive = true
        spinner.heightAnchor.constraint(equalToConstant: 80).isActive = true

        updateUI(animated: false)
        setWorking(false, animated: false)
    }

    // MARK: - Internal Functions
    func setWorking(_ loading: Bool, animated: Bool = true) {
        subviews.forEach { $0.isUserInteractionEnabled = !loading }

        let alpha: CGFloat = loading ? 1 : 0

        UIView.animate(withDuration: animated ? 0.35 : 0) {
            self.workingBackground.alpha = alpha
            self.spinner.alpha = alpha
        }
    }

    // MARK: - Private Functions
    private func updateUI(animated: Bool = true) {
        let visible: [UIView]

        switch mode {
        case .social:   visible = [title, facebookLogin, googleLogin, showEmailLogin]
        case .email:    visible = [title, email, emailLogin, cancelEmailLogin]
        }

        UIView.animate(withDuration: animated ? 0.35 : 0) {
            for view in self.subviews {
                view.alpha = visible.contains(view) ? 1 : 0
            }
        }
    }
    @objc private func toggleState() {
        mode = mode.flipped

        switch mode {
        case .social:
            email.resignFirstResponder()
        case .email:
            email.becomeFirstResponder()
        }
    }
}
