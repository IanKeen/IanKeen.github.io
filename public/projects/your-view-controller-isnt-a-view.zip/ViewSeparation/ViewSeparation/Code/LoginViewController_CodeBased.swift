//
//  LoginViewController_Code.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-26.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit

class LoginViewController_Code: UIViewController {
    // MARK: - View Separation
    private var customView: LoginView_Code { return view as! LoginView_Code }

    // MARK: - Lifecycle
    override func loadView() {
        self.view = LoginView_Code()
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        startTrackingKeyboard()
        customView.facebookLogin.addTarget(self, action: #selector(facebookLoginTouchUpInside(sender:)), for: .touchUpInside)
        customView.googleLogin.addTarget(self, action: #selector(googleLoginTouchUpInside(sender:)), for: .touchUpInside)
        customView.emailLogin.addTarget(self, action: #selector(emailLoginTouchUpInside(sender:)), for: .touchUpInside)
    }

    // MARK: - Actions
    @objc private func facebookLoginTouchUpInside(sender: UIButton) {
        doWork("Facebook login")
    }
    @objc private func googleLoginTouchUpInside(sender: UIButton) {
        doWork("Google login")
    }
    @objc private func emailLoginTouchUpInside(sender: UIButton) {
        if let email = customView.email.text, !email.isEmpty {
            doWork("Create account for: \(email)")

        } else {
            presentError("Please enter your email")
        }
    }

    // represents some async task, api call etc..
    private func doWork(_ name: String) {
        print(name)
        customView.setWorking(true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.customView.setWorking(false)
        }
    }
}
