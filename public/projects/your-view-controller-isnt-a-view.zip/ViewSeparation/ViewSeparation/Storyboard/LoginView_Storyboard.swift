//
//  LoginView_Storyboard.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-28.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit

class LoginView_Storyboard: UIView {
    // MARK: - Elements
    @IBOutlet private(set) var socialItems: [UIView]!
    @IBOutlet private(set) var emailItems: [UIView]!
    @IBOutlet private(set) var workingItems: [UIView]!
    @IBOutlet private(set) var email: UITextField!

    // MARK: - Private Properties
    private var mode: LoginViewMode = .social {
        didSet { updateUI() }
    }

    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()

        updateUI(animated: false)
        setWorking(false, animated: false)
    }

    // MARK: - Internal Functions
    func setWorking(_ loading: Bool, animated: Bool = true) {
        subviews.forEach { $0.isUserInteractionEnabled = !loading }

        let alpha: CGFloat = loading ? 1 : 0

        UIView.animate(withDuration: animated ? 0.35 : 0) {
            for view in self.workingItems {
                view.alpha = alpha
            }
        }
    }

    // MARK: - Private Functions
    private func updateUI(animated: Bool = true) {
        let visible: [UIView]

        switch mode {
        case .social:   visible = socialItems
        case .email:    visible = emailItems
        }

        UIView.animate(withDuration: animated ? 0.35 : 0) {
            for view in self.subviews {
                view.alpha = visible.contains(view) ? 1 : 0
            }
        }
    }
    @IBAction private func toggleState() {
        mode = mode.flipped

        switch mode {
        case .social:
            email.resignFirstResponder()
        case .email:
            email.becomeFirstResponder()
        }
    }
}
