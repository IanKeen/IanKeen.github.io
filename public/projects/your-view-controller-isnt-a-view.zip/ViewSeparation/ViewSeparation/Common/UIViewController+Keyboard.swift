//
//  UIViewController+Keyboard.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-26.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit
import ObjectiveC

struct KeyboardFrameChange {
    let start: CGRect
    let end: CGRect
    let duration: TimeInterval

    fileprivate init?(notification: Notification) {
        guard
            let info = notification.userInfo,
            let start = info[UIKeyboardFrameBeginUserInfoKey] as? CGRect,
            let end = info[UIKeyboardFrameEndUserInfoKey] as? CGRect,
            let duration = info[UIKeyboardAnimationDurationUserInfoKey] as? TimeInterval
            else { return nil }

        self.start = start
        self.end = end
        self.duration = duration
    }
}

private var token = "_keyboardTracker"

extension UIViewController {
    private var notificationTokens: NSObjectProtocol? {
        get { return objc_getAssociatedObject(self, &token) as? NSObjectProtocol }
        set { objc_setAssociatedObject(self, &token, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC) }
    }

    func startTrackingKeyboard() {
        notificationTokens.map(NotificationCenter.default.removeObserver)

        notificationTokens = NotificationCenter.default.addObserver(forName: .UIKeyboardWillChangeFrame, object: nil, queue: .main, using: { notification in
            guard let change = KeyboardFrameChange(notification: notification) else { return }

            UIView.animate(
                withDuration: change.duration,
                delay: 0,
                options: .beginFromCurrentState,
                animations: {
                    self.view.updateHeight(from: change)
                },
                completion: nil
            )
        })

    }
    func stopTrackingKeyboard() {
        notificationTokens.map(NotificationCenter.default.removeObserver)
    }
}

private extension UIView {
    func updateHeight(from change: KeyboardFrameChange) {
        frame = CGRect(
            origin: .zero,
            size: CGSize(
                width: bounds.width,
                height: frame.size.height + (change.end.origin.y - change.start.origin.y)
            )
        )
    }
}
