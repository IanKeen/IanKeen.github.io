//
//  Common.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-26.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import Foundation

/// Used by each login view
enum LoginViewMode {
    case social, email

    var flipped: LoginViewMode {
        switch self {
        case .social: return .email
        case .email: return .social
        }
    }
}
