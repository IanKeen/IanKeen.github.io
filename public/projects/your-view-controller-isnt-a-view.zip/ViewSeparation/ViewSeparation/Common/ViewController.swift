//
//  ViewController.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-26.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit

class ViewController<T: UIView>: UIViewController {
    // MARK: - View Separation
    var customView: T { return view as! T }

    // MARK: - Lifecycle
    override func loadView() {
        self.view = T()
    }
}
