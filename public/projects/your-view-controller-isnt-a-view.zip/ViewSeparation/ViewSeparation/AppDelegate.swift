//
//  AppDelegate.swift
//  ViewSeparation
//
//  Created by Ian Keen on 2017-09-26.
//  Copyright © 2017 Ian Keen. All rights reserved.
//

import UIKit

enum ExampleMode {
    case code, nib, storyboard
}

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    let mode: ExampleMode = .storyboard

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)

        switch mode {
        case .code:
            window.rootViewController = LoginViewController_Code()

        case .nib:
            window.rootViewController = LoginViewController_Nib()

        case .storyboard:
            let storyboard = UIStoryboard(name: "Storyboard", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "LoginViewController")
            window.rootViewController = viewController
        }

        window.makeKeyAndVisible()
        self.window = window
        return true
    }
}
