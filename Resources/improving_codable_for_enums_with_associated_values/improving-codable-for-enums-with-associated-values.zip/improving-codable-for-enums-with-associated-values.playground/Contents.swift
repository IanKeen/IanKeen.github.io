import Foundation

struct User: Codable {
    let name: String
    let url: URL
}
enum AuthState: Codable {
    case loggedIn(User)
    case loggedOut
}

extension AuthState {
    private enum CodingKeys: String, CodingKey {
        case loggedIn, loggedOut
    }
}
extension AuthState {
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)

        switch self {
        case .loggedIn(let user): try container.encode(user, forKey: .loggedIn)
        case .loggedOut:          try container.encode(CodingKeys.loggedOut.stringValue, forKey: .loggedOut)
        }
    }
}
extension AuthState {
    init(from decoder: Decoder) throws {
        self = try decode(using: decoder.container(keyedBy: CodingKeys.self), cases: [
            value(AuthState.loggedIn, for: .loggedIn),
            value(AuthState.loggedOut, for: .loggedOut),
            ]
        )
    }
}

let values: [AuthState] = [
    .loggedIn(User(name: "Ian Keen", url: URL(string: "http://iankeen.tech")!)),
    .loggedOut,
]
for value in values {
    let encoded = try JSONEncoder().encode(value)
    print("Encoded to:", String(data: encoded, encoding: .utf8)!)

    let decoded = try JSONDecoder().decode(AuthState.self, from: encoded)
    print("Decoded as:", decoded)

    print("\n")
}
